<?php
$server = 'localhost';
$username = 'root';
$password = '';
$db = 'employees_crud';

$conn = new mysqli($server, $username, $password, $db);

if (!$conn) {
  echo "Database not connected";
}
