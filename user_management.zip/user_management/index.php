<?php
include 'db.php';

if (isset($_POST["add"])) {
  $name = $_POST["name"];
  $sal = $_POST["salary"];
  $dept = $_POST["dept"];

  $sql = $conn->prepare("insert into data(name,salary,designation) values(?,?,?)");
  $sql->bind_param('sds', $name, $sal, $dept);
  if ($sql->execute()) {
    header("Locarion: index.php");
  }
}

$r1 = $conn->query("select * from data");

if (isset($_GET["delete"])) {
  $id = $_GET["delete"];
  if (isset($_GET['confirm']) && $_GET['confirm'] === "yes") {
    $result = $conn->prepare("delete from data where id=?");
    $result->bind_param('i', $id);
    $result->execute();
    header("Location:index.php");
  }
  $confirmMessage = true;
}

$editid = isset($_GET['edit']) ? $_GET['edit'] : null;

if (isset($_POST["update"])) {
  $id = $_POST['id'];
  $name = $_POST['name'];
  $salary = $_POST['salary'];
  $designation = $_POST['designation'];
  $statement = $conn->query("update data set name='$name', salary='$salary', designation='$designation' where id=$id");
  header("Location: index.php");
}
?>
<!doctype html>
<html lang="en">

<head>
  <title>Title</title>
  <!-- Required meta tags -->
  <meta charset="utf-8" />
  <meta
    name="viewport"
    content="width=device-width, initial-scale=1, shrink-to-fit=no" />

  <!-- Bootstrap CSS v5.2.1 -->
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
    rel="stylesheet"
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN"
    crossorigin="anonymous" />
</head>

<body>
  <div
    class="container text-center my-5">
    <div class="container text-center">
      <h1>User Management</h1>
      <form method="post">
        <div class="mb-3 row">
          <label
            for="inputName"
            class="col-4 col-form-label">Name</label>
          <div
            class="col-8">
            <input
              type="text"
              class="form-control"
              name="name"
              id="inputName"
              placeholder="Name" required />
          </div>
        </div>
        <div class="mb-3 row">
          <label
            for="inputName"
            class="col-4 col-form-label">Salary</label>
          <div
            class="col-8">
            <input
              type="text"
              class="form-control"
              name="salary"
              id="inputName"
              placeholder="Salary" required />
          </div>
        </div>
        <div class="mb-3 row">
          <label
            for="inputName"
            class="col-4 col-form-label">Department</label>
          <div
            class="col-8">
            <input
              type="text"
              class="form-control"
              name="dept"
              id="inputName"
              placeholder="Department" required />
          </div>
        </div>
        <div class="mb-3 row">
          <div class="offset-sm-4 col-sm-8">
            <button name="add" class="btn btn-primary text-center">
              Add Employee
            </button>
          </div>
        </div>
      </form>
    </div>
    <div>
      <div
        class="table-responsive">
        <table
          class="table table-primary ">
          <thead>
            <tr>
              <th scope="col">ID</th>
              <th scope="col">Name</th>
              <th scope="col">Salary</th>
              <th scope="col">Department</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
            <?php
            while ($row = $r1->fetch_assoc()) {
              if ($editid == $row['id']) { ?>
                <form method="post">
                  <tr class="">
                    <td><?= $row['id'] ?></td>
                    <td><input type="text" name="name" value="<?= $row['name'] ?>" required></td>
                    <td><input type="text" name="salary" value="<?= $row['salary'] ?>" required></td>
                    <td><input type="text" name="designation" value="<?= $row['designation'] ?>" required></td>
                    <td><input type="hidden" name="id" value="<?= $row['id'] ?>">
                      <button type="submit" name="update" class="btn btn-primary">Save</button>
                      <a href="index.php" class="btn btn-secondary">Cancel</a>
                    </td>
                  </tr>
                </form>
              <?php } else { ?>
                <tr>
                  <td scope="row"><?= $row["id"] ?></td>
                  <td><?= $row["name"] ?></td>
                  <td><?= $row["salary"] ?></td>
                  <td><?= $row["designation"] ?></td>
                  <td><a href="?edit=<?= $row['id'] ?>" class="btn btn-primary">Edit</a>|<a href="?delete=<?= $row['id'] ?>" class="btn btn-danger">Delete</a></td>
                </tr>
            <?php }
            } ?>
          </tbody>
        </table>
      </div>
      <?php if (isset($confirmMessage)) { ?>
        <div>
          Are you sure you want to delete this employee?
          <a href="?delete=<?= $id ?>&confirm=yes">Yes</a>
          <a href="index.php">Cancel</a>
        </div>
      <?Php } ?>
    </div>
  </div>

  <!-- Bootstrap JavaScript Libraries -->
  <script
    src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
    integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
    crossorigin="anonymous"></script>

  <script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
    integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+"
    crossorigin="anonymous"></script>
</body>

</html>